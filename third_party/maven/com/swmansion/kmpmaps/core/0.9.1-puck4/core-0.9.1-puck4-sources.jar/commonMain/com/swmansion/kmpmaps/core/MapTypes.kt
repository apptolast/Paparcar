package com.swmansion.kmpmaps.core

import androidx.annotation.RestrictTo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonIgnoreUnknownKeys

/**
 * Theme options for map appearance.
 *
 * @property SYSTEM Follows the system's dark theme setting
 * @property LIGHT Always uses light theme
 * @property DARK Always uses dark theme
 */
public enum class MapTheme {
    SYSTEM,
    LIGHT,
    DARK,
}

/**
 * Insets that define map content padding in platform pixels.
 *
 * @property top Top inset
 * @property bottom Bottom inset
 * @property start Start inset (left in LTR layout)
 * @property end End inset (right in LTR layout)
 */
public data class MapContentPadding(
    val top: Float = 0f,
    val bottom: Float = 0f,
    val start: Float = 0f,
    val end: Float = 0f,
)

/**
 * Configuration properties for map behavior and appearance.
 *
 * @property isMyLocationEnabled Whether to show the user's current location on the map
 * @property isTrafficEnabled Whether to display traffic information on the map
 * @property isBuildingEnabled Whether to show 3D buildings on the map
 * @property mapType The type of map to display
 * @property mapTheme The theme for the map appearance
 * @property contentPadding Padding applied to map content (top, bottom, start, end). Does not apply
 *   to JVM
 * @property androidMapProperties Android-specific map behavior and appearance configuration options
 * @property iosMapProperties iOS-specific map behavior and appearance configuration options
 * @property webMapProperties Desktop-specific map behavior and appearance configuration options
 */
public data class MapProperties(
    val isMyLocationEnabled: Boolean = false,
    val isTrafficEnabled: Boolean = true,
    val isBuildingEnabled: Boolean = true,
    val mapType: MapType = MapType.NORMAL,
    val mapTheme: MapTheme = MapTheme.SYSTEM,
    val contentPadding: MapContentPadding? = null,
    val androidMapProperties: AndroidMapProperties = AndroidMapProperties(),
    val iosMapProperties: IosMapProperties = IosMapProperties(),
    val webMapProperties: WebMapProperties = WebMapProperties(),
)

/**
 * UI settings that control interactive elements and gestures on the map.
 *
 * @property compassEnabled Whether to show the compass control
 * @property myLocationButtonEnabled Whether to show the "My Location" button
 * @property scaleBarEnabled Whether to show the scale bar
 * @property togglePitchEnabled Whether pitch gestures are enabled
 * @property scrollEnabled Whether scroll gestures are enabled
 * @property zoomEnabled Whether zoom gestures are enabled
 * @property rotateEnabled Whether rotation gestures are enabled
 * @property androidUISettings Android-specific UI settings
 * @property iosUISettings iOS-specific UI settings
 * @property webUISettings Desktop-specific UI settings
 */
public data class MapUISettings(
    val compassEnabled: Boolean = false,
    val myLocationButtonEnabled: Boolean = false,
    val scaleBarEnabled: Boolean = true,
    val togglePitchEnabled: Boolean = true,
    val scrollEnabled: Boolean = true,
    val zoomEnabled: Boolean = true,
    val rotateEnabled: Boolean = true,
    val androidUISettings: AndroidUISettings = AndroidUISettings(),
    val iosUISettings: IosUISettings = IosUISettings(),
    val webUISettings: WebUISettings = WebUISettings(),
)

/**
 * Represents a marker on the map.
 *
 * @property coordinates The geographical coordinates where the marker should be placed.
 *
 * Note on Mutability: Although this is a `var` to allow the library to update positions during
 * dragging, you should treat it as immutable. To move the marker programmatically, pass a new
 * [Marker] instance to the map.
 *
 * Directly mutating this field may not trigger UI updates, especially on iOS.
 *
 * @property title The title text displayed when the marker is tapped
 * @property androidMarkerOptions Android-specific options for customizing a marker
 * @property iosMarkerOptions iOS-specific options for customizing a marker
 * @property contentId Optional identifier for custom content.
 * - On **Mobile**: Used to look up a Composable in the Map's `customMarkerContent` parameter.
 * - On **Desktop**: Used to look up an HTML template in the Map's `webCustomMarkerContent`
 *   parameter.
 */
@Serializable
@JsonIgnoreUnknownKeys
@OptIn(ExperimentalSerializationApi::class)
public data class Marker(
    var coordinates: Coordinates,
    val title: String? = "No title was provided",
    val androidMarkerOptions: AndroidMarkerOptions = AndroidMarkerOptions(),
    val iosMarkerOptions: IosMarkerOptions? = null,
    val contentId: String? = null,
    val id: String? = null,
)

/**
 * Stable identity used to key the marker in the Compose tree and native caches.
 *
 * When [Marker.id] is provided it is used verbatim, so a marker that only changes its
 * [Marker.coordinates] keeps the same identity across recompositions — the marker is
 * repositioned in place instead of being disposed and recreated (which causes flicker on
 * markers that move every frame, e.g. a live driving puck).
 *
 * When [Marker.id] is null it falls back to the structural [hashCode], preserving the
 * previous behaviour for callers that do not opt in.
 *
 * @suppress
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun Marker.getId(): String = id?.let { "marker_$it" } ?: "marker_${hashCode()}"

/**
 * A marker whose POSITION changes frequently (e.g. a live vehicle puck). Its [position] and [rotation]
 * are observable Compose [State] read by the map INSIDE its own isolated scope, so updating them does
 * NOT recompose the caller — the marker glides to each new position natively, off the recomposition
 * path. Use this for anything that moves continuously; a normal [Marker] in the `markers` list
 * recomposes the whole map on every move. [DRIVE-PUCK-NATIVE-001]
 *
 * @property id Stable identity.
 * @property contentId Looks up the composable in the Map's `customMarkerContent`.
 * @property position Observable geographic position; changes glide natively.
 * @property rotation Observable rotation in degrees (clockwise).
 * @property androidMarkerOptions Android-specific options (anchor, zIndex, flat, …).
 */
public class LiveMarker(
    public val id: String,
    public val contentId: String?,
    public val position: State<Coordinates>,
    public val rotation: State<Float>,
    public val androidMarkerOptions: AndroidMarkerOptions = AndroidMarkerOptions(),
)

/**
 * Represents a circle overlay on the map.
 *
 * @property center The center coordinates of the circle
 * @property radius The radius of the circle in meters
 * @property color The fill color of the circle
 * @property lineColor The color of the circle's border
 * @property lineWidth The width of the circle's border
 */
public data class Circle(
    val center: Coordinates,
    val radius: Float,
    val color: Color? = null,
    val lineColor: Color? = null,
    val lineWidth: Float? = null,
)

/** @suppress */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun Circle.getId(): String = "circle_${hashCode()}"

/**
 * Represents a polygon overlay on the map.
 *
 * @property coordinates List of coordinates that define the polygon's vertices
 * @property lineWidth The width of the polygon's border
 * @property color The fill color of the polygon
 * @property lineColor The color of the polygon's border
 */
public data class Polygon(
    val coordinates: List<Coordinates>,
    val lineWidth: Float,
    val color: Color? = null,
    val lineColor: Color? = null,
)

/** @suppress */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun Polygon.getId(): String = "polygon_${hashCode()}"

/**
 * Represents a polyline overlay on the map.
 *
 * @property coordinates List of coordinates that define the polyline's path
 * @property width The width of the polyline
 * @property lineColor The color of the polyline
 */
public data class Polyline(
    val coordinates: List<Coordinates>,
    val width: Float,
    val lineColor: Color? = null,
)

/** @suppress */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public fun Polyline.getId(): String = "polyline_${hashCode()}"

/**
 * Represents geographical coordinates (latitude and longitude).
 *
 * @property latitude The latitude coordinate in decimal degrees (-90 to 90)
 * @property longitude The longitude coordinate in decimal degrees (-180 to 180)
 */
@Serializable public data class Coordinates(val latitude: Double, val longitude: Double)

/**
 * Represents the visible geographic bounds of the map.
 *
 * @property northeast The northeast corner coordinates of the visible region
 * @property southwest The southwest corner coordinates of the visible region
 */
@Serializable public data class MapBounds(val northeast: Coordinates, val southwest: Coordinates)

/**
 * Represents the camera position and orientation of the map.
 *
 * **Configuration Rules:** To successfully initialize, you must provide either:
 * 1. Both [coordinates] **and** [zoom].
 * 2. Or [bounds] (which takes precedence for positioning).
 *
 * @property coordinates The center coordinates of the camera view, or null to use [bounds] center
 * @property zoom The zoom level of the map (typically 0–20), or null to use default (0)
 * @property bounds The geographic bounds to fit in the viewport, or null if not used
 * @property androidCameraPosition Android-specific options for the camera position and orientation
 * @property iosCameraPosition iOS-specific options for the camera position and orientation
 */
@Serializable
public data class CameraPosition(
    val coordinates: Coordinates? = null,
    val zoom: Float? = null,
    val bounds: MapBounds? = null,
    val androidCameraPosition: AndroidCameraPosition? = null,
    val iosCameraPosition: IosCameraPosition? = null,
) {
    init {
        require((coordinates != null && zoom != null) || bounds != null) {
            "CameraPosition requires at least one of 'coordinates' or 'bounds' to be set."
        }
    }
}

/**
 * Represents a group of markers that have been combined into a single cluster.
 *
 * @property coordinates The coordinates of the cluster
 * @property size The number of markers contained within this cluster
 * @property items The list of [Marker] that make up this cluster
 */
@Serializable
public data class Cluster(val coordinates: Coordinates, val size: Int, val items: List<Marker>)

/**
 * Configuration options for marker clustering.
 *
 * @property enabled Enables marker clustering
 * @property onClusterClick Callback invoked on cluster click. Return `true` to consume the event or
 *   `false` to allow the default platform behavior
 * @property clusterContent Optional Composable to render custom cluster UI
 * @property webClusterContent Optional function to render custom cluster UI as HTML string
 */
public data class ClusterSettings(
    val enabled: Boolean = false,
    val onClusterClick: ((Cluster) -> Boolean)? = null,
    val clusterContent: (@Composable (Cluster) -> Unit)? = null,
    val webClusterContent: ((Cluster) -> String)? = null,
)

internal object ColorSerializer : KSerializer<Color> {
    override val descriptor = PrimitiveSerialDescriptor("Color", PrimitiveKind.INT)

    override fun serialize(encoder: Encoder, value: Color) {
        encoder.encodeInt(value.toArgb())
    }

    override fun deserialize(decoder: Decoder) = Color(decoder.decodeInt())
}
